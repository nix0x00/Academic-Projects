/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sleepysaloon;

/**
 *
 * @author Hadaya
 */
public class SleepySaloon {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Accessories as1 = new Accessories();
    Accessories as2 = new Accessories();
       
    Customer c[] = new Customer[30];
      
    HairDresser h[] = new HairDresser[4];
       
    Saloon s = new Saloon(h, c, as1, as2);     
       
    for(int k = 1; k < h.length; k++){
    h[k] = new HairDresser("HD "+k, s);
    h[k].start();
    } // end for   
       
    for(int i = 5; i < c.length; i++){
    c[i] = new Customer(i, s);
    c[i].start();
    } // end for

   }
    
} // end class
