/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sleepysaloon;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Hadaya
 */
public class Saloon {
    protected int c;
    protected boolean as1_available = true; // accessories set 1
    protected boolean as2_available = true; // accessories set 2
    protected Accessories as1; // object of accessories class
    protected Accessories as2;
    protected HairDresser hd[]; // hairdresser object
    protected Customer cust[]; // customer object
    protected boolean finish_haircut = false; // to report when haircut finishes
    protected boolean chair = true; // to change state of chair when customers sit
    Queue<Customer> saloon; // to add customers who are having haircut
    Queue<Customer> sit; // to add customers in the sitting area
    Queue<Customer> stand; // to add customers in the standing area
    Queue<HairDresser> hrdr; // to add sleeping hairdressers and retrieve them at wake up time
    protected boolean hd_status = true; // determine if hairdresser is free
    protected boolean cust_leave = false; // notifies when customer leaves saloon
    protected boolean awake = true; // hairdresser is awake.
    protected static int sit_count = 0; // counting customers in the sitting area
    protected static int stand_count = 0; // counting customers in the standing area
    static int sit_for_cut = 0; // counting customers having haircut 
    static int cust_count = 0; // count of entering customers
    Random rn = new Random(); // to be used to have sleep time during haircut
    
    public Saloon(HairDresser hd[], Customer c[], Accessories a1, Accessories a2){
        this.hd = hd;
        this.cust = c;
        this.as1 = a1;
        this.as2 = a2;
        hrdr = new LinkedList<HairDresser>();
        saloon = new LinkedList<Customer>();
        sit = new LinkedList<Customer>();
        stand = new LinkedList<Customer>();
    }
    
    
public void sleep(HairDresser h){
synchronized(this){    
if(chair == true && saloon.isEmpty()){ // no customer

    try {
    Thread.sleep(500);
    } catch (InterruptedException ex) {
    Logger.getLogger(HairDresser.class.getName()).log(Level.SEVERE, null, ex);
    }

System.out.println("Hairdresser "+h.hn+" sleeps, no customer.."); // hairdresser sleeps
hrdr.offer(h); // sleeping hairdressers added in queue
}

while(cust_count == 0){ // no customers
  try {
  wait(); // wait for incoming customers
  try {
  Thread.sleep(100);
  } catch (InterruptedException ex) {
  Logger.getLogger(HairDresser.class.getName()).log(Level.SEVERE, null, ex);
  }
  } catch (InterruptedException e) {
  e.printStackTrace();
 }
} // end while for wait condition

System.out.println("Hairdresser "+hrdr.peek().hn+" wakes up."); // notification recieved from hairdresser who awakes
hrdr.poll(); // awaken hairdresser removed from queue
awake = true; // awake status setted true
if(awake == true) // notifying customer when awake status of hairdresser is true
notify();
 } // end synchronized block
} // sleep method end


public void cust_ch(Customer c){
System.out.println("Customer "+c.c+" enters saloon..");
cust_count++; // entering customers count incremented

synchronized(this){
if(cust_count == 3)  // notifying hairdresser that customers are inside saloo, he should wake up
notify();
}     
        try {
        Thread.sleep(1000);
        } catch (InterruptedException ex) {
        Logger.getLogger(Saloon.class.getName()).log(Level.SEVERE, null, ex);
        }
        
synchronized(this){
while(awake != true){ // waiting for the hairdresser to wake up
    try {
    wait();
    } catch (InterruptedException ex) {
    Logger.getLogger(HairDresser.class.getName()).log(Level.SEVERE, null, ex);
    }
} // end while for condition

if(sit_for_cut < 3){  // customer sits for haircut if count is less than 3 as there are 3 chairs
  // c.l.tryLock();
    System.out.println("Customer "+c.c+" sat for haircut..");
    chair = false; // as customer sits for haircut now..
    saloon.offer(c); // customer having haircut added to queue
    notify();
    sit_for_cut++; // sitting for haircut count incremented
    //try {Thread.sleep(300); } catch(Exception x) {}
    //c.l.unlock();
}

        try {
            Thread.sleep(6000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Saloon.class.getName()).log(Level.SEVERE, null, ex);
        }

 if(sit_count < 10 && sit_for_cut == 3){ // if all cutting chairs filled up but space in sitting area
 sitAdd(c);
 }
 
 if(sit_count >= 10 && stand_count < 10){ // if all sitting area filled up but space in standing area
 standAdd(c);
 }
 
 if(stand_count >= 10) // if sitting area standing area and all cuttng chairs filled up
 System.out.println("Saloon full, (stand count: "+stand_count+") customer "+c.c+" leaves saloon..");
} // end synchronized block

  try{
  Thread.sleep(1000);
  } catch(Exception x){}
 
} // end function
        

public void sitAdd(Customer c){
    
    try{
    Thread.sleep(1000);
    } catch(Exception x){}
    
System.out.println("All cutting seats reserved, customer "+c.c+" waits in sitting area. ");
sit.offer(c); // customers being added to sitting area queue
sit_count++; // sitting area count incremented

        try {
        Thread.sleep(2000);
        } catch (InterruptedException ex) {
        Logger.getLogger(Saloon.class.getName()).log(Level.SEVERE, null, ex);
        }

synchronized(this){
if(sit_for_cut > 3){ // if all cutting chairs filled, wait
try {
wait();
} catch (InterruptedException ex) {
Logger.getLogger(HairDresser.class.getName()).log(Level.SEVERE, null, ex);
 }   
} // end condition

      try{
      Thread.sleep(1000);
      } catch(Exception x){}
} // end synchronized block

if(sit_for_cut < 3){ // a customer might leave and free a chair
System.out.println("Chairs free now.. Customer "+sit.peek().c+" goes for haircut.");
sit.poll(); // removed from sit queue
saloon.offer(c); // added to cutting queue
chair = false;
sit_for_cut++;
sit_count--;
} // end if

        try {
        Thread.sleep(1000);
        } catch (InterruptedException ex) {
         Logger.getLogger(HairDresser.class.getName()).log(Level.SEVERE, null, ex);
        }

synchronized(this){
if(sit_count < 10)
notify(); // move to sitting area from standing.
} // synchronized block

} // method end
 

public void standAdd(Customer c){
    
    try{
    Thread.sleep(1000);
    } catch(Exception x){}
    
System.out.println("Sitting area filled up, (sit count: "+sit_count+") customer "+c.c+" waits in standing area.");
stand.offer(c);
stand_count++;

synchronized(this){
if(sit_count > 10){
   try {
   wait();
   } catch (InterruptedException ex) {
   Logger.getLogger(HairDresser.class.getName()).log(Level.SEVERE, null, ex);
   }
  } // end condition 

     try{
     Thread.sleep(1000);
     } catch(Exception x){}

if(sit_count < 10){
System.out.print("Space in sitting area made, customer "+stand.peek().c+" moves in sitting area from standing area.");
stand.poll();
stand_count--;
sit_count++;
sit.offer(c);
  } // end if
 } // end synchronize block
} // end method


public void hair_cut(HairDresser hd){
if(hd.lock.tryLock()){
//while(chair == false){
System.out.println("hairdresser "+hd.hn+" goes to chair");
hd_status = false;
if(as1.l.tryLock()){
System.out.println("Hairdresser "+hd.hn+" grabs combscissor set 1.");
as1_available = false;
System.out.println("Hairdresser "+hd.hn+" starts haircut of customer "); 
System.out.println("Hairdresser "+hd.hn+" cuts hair of customer "); 

    try{
    Thread.sleep(rn.nextInt(6)+ 3);} // haircut time
    catch(Exception ex){}
 
System.out.println("Hairdresser "+hd.hn+" finishes haircut of customer "); 
finish_haircut = true;
System.out.println("Hairdresser "+hd.hn+" keeps back comb and scissor set");
as1.l.unlock();
as1_available = true;

synchronized(this){
if(cust_leave != true){
     try {
     wait();
     } catch (InterruptedException ex) {
     Logger.getLogger(HairDresser.class.getName()).log(Level.SEVERE, null, ex);
    }
} // wait condition end

 System.out.println("Haircut done, "+hd.hn+" available");
 hd.lock.unlock();
 sit_for_cut--;
 chair = true;
} // end synchronized block

 synchronized(this){ // notify that sit count decreased
 if(sit_for_cut < 3)
 notify();
 } // end last synchronized block
 } // if 1st comb set acquired

else if(as2.l.tryLock()){
System.out.println("Hairdresser "+hd.hn+" grabs combscissor set 2.");
as2_available = false;
System.out.println("Hairdresser "+hd.hn+" starts haircut of customer "); 
System.out.println("Hairdresser "+hd.hn+" cuts hair of customer "); 
 
    try{
    Thread.sleep(rn.nextInt(6)+ 3);}
    catch(Exception ex){}
 
System.out.println("Hairdresser "+hd.hn+" finishes haircut of customer "); 
finish_haircut = true;
System.out.println("Hairdresser "+hd.hn+" keeps back comb and scissor set");
as2.l.unlock();
as2_available = true;
 
synchronized(this){
if(cust_leave == false){
 try {
 wait();
 } catch (InterruptedException ex) {
 Logger.getLogger(HairDresser.class.getName()).log(Level.SEVERE, null, ex);
 }
} // wait condition ends

System.out.println("Haircut done, "+hd.hn+" available");
hd.lock.unlock();
sit_for_cut--;
chair = true;
} // end synchronized block

synchronized(this){
if(cust_count < 3 && chair == true)
notify();
  } // end synchronized block
 } // if 2nd comb set acquired

else{
System.out.println("Hairdresser "+hd.hn+" cannot grab comb and scissor set..");
hd.lock.unlock();
   } 
  } // if lock applied
//} // end while loop

} // end method


public void cust_payment(Customer c){
    
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(HairDresser.class.getName()).log(Level.SEVERE, null, ex);
        }
        
synchronized(this){
if (finish_haircut == true && chair == false){
saloon.poll();
System.out.println("Customer "+saloon.peek().c+" does payment.");
System.out.println("Customer "+saloon.peek().c+" leaves saloon..");
cust_leave = true;
chair = true;
}
      
if(cust_leave == true){
notify();
return;
   }
  } // end synchronized bock
 } // end method

} // end class






