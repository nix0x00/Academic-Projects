/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sleepysaloon;
/**
 *
 * @author Hadaya
 */
public class Customer extends Thread {
    protected int c;
    protected Saloon s;
   
    public Customer(int no, Saloon s){
        this.c = no;
        this.s = s;
    }
   
   
@Override   
public void run(){  
    while(true){  
    try{
    Thread.sleep(2000);
    } catch(Exception x){}
    
s.cust_ch(this);    
      
    try{
    Thread.sleep(2000);
    } catch(Exception x){}
       
s.cust_payment(this);
} // end method run
}


} // end class
