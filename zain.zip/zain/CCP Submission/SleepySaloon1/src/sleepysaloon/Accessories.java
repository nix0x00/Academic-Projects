/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sleepysaloon;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 *
 * @author Hadaya
 */
public class Accessories {
     Lock l;
    
    public Accessories(){
        l = new ReentrantLock();
    }
    
}
