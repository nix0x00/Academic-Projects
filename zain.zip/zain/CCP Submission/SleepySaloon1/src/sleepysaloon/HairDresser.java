/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sleepysaloon;

import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Hadaya
 */
public class HairDresser extends Thread{
    protected String hn; // number of hair dresser 
    Saloon s;
    Lock lock;
    Random rn = new Random();
    
    public HairDresser(String hr, Saloon s){
    this.hn = hr;
    this.s = s;
    lock =  new ReentrantLock();
    }
    
    
public void run() {
s.sleep(this);
        
    try {
    Thread.sleep(5000);
    } catch (InterruptedException ex) {
    Logger.getLogger(HairDresser.class.getName()).log(Level.SEVERE, null, ex);
    }
    
s.hair_cut(this);
 } // end method run

}
